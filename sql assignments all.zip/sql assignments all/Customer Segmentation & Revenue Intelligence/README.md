### Business Problem Statement

A digital media company generates sales data across customers, countries, artists, tracks, genres, and invoices. However, raw transaction data alone does not provide clear information about customer value, purchasing frequency, customer segments, revenue contribution, or purchasing preferences.

This project uses SQL to analyze the Chinook database and transform transactional sales data into meaningful customer and revenue intelligence. The analysis focuses on identifying valuable customers, purchasing patterns, customer segments, high-value countries, popular genres, high-revenue artists, and revenue trends.

### Business Questions

The analysis answers the following business questions:

1. Who are the highest-spending customers?
2. Who are the most frequent purchasers?
3. Which customers have not purchased recently?
4. Which countries have the highest-value customers?
5. What is the average customer lifetime spending?
6. How can customers be segmented into High, Medium, and Low Value groups?
7. Which genres are most popular?
8. Which artists generate the highest revenue?
9. Which tracks are purchased most frequently?
10. How do customers rank by spending within each country?
11. Which customers spend above the average?
12. Who are the top 3 customers in each country?
13. Which customers have purchased from multiple genres?
14. What percentage of total revenue does each customer contribute?
15. What is the cumulative revenue over time?
16. Which month generates the highest revenue?

### SQL Analysis and Results

The project uses SQL to perform customer, sales, geographic, music, and revenue analysis across customers, invoices, invoice line items, tracks, genres, albums, and artists.

The analysis includes:

* Highest-spending customer identification
* Purchase frequency analysis
* Recent customer purchase activity
* Country-wise customer value analysis
* Average customer lifetime spending
* Customer segmentation using CASE
* Genre popularity analysis
* Artist revenue analysis
* Track purchase frequency analysis
* Customer ranking within countries
* Above-average customer identification
* Top 3 customers in each country
* Multi-genre customer analysis
* Customer revenue contribution percentage
* Monthly revenue analysis
* Cumulative revenue calculation
* Highest-revenue month identification

SQL techniques used include:

* INNER JOIN
* GROUP BY
* ORDER BY
* HAVING
* Aggregate functions
* Subqueries
* Common Table Expressions (CTEs)
* CASE statements
* Date functions
* RANK()
* ROW_NUMBER()
* Window functions

The detailed SQL queries are available in `customer_segmentation_analysis.sql`.

### Key Findings

The key findings are based on the results generated from the SQL analysis.

* The highest-spending customers were identified based on total lifetime spending.
* Customers with the highest purchase frequency were identified.
* Customers who have not purchased recently were identified.
* Countries containing high-value customers were identified.
* Average customer lifetime spending was calculated.
* Customers were classified into High, Medium, and Low Value segments.
* The most popular genres and frequently purchased tracks were identified.
* Artists generating the highest revenue were identified.
* Customers were ranked according to spending within their respective countries.
* Customers spending above the overall average were identified.
* The top 3 customers in each country were identified.
* Customers purchasing from multiple genres were identified.
* Each customer's percentage contribution to total revenue was calculated.
* Cumulative revenue was calculated using window functions.
* The month with the highest revenue was identified.

### Business Insights

The analysis provides insights into customer value, purchasing behavior, geographic distribution, music preferences, and revenue performance.

* High-value customers represent an important customer segment for the business.
* Customer segmentation can help differentiate customers based on their spending levels.
* Purchase frequency can help identify customers with stronger purchasing activity.
* Customers who have not purchased recently can represent a potential segment for customer engagement and retention activities.
* Country-level customer analysis helps identify geographic markets containing valuable customers.
* Popular genres and frequently purchased tracks provide insights into customer music preferences.
* High-revenue artists can indicate areas of strong customer demand.
* Customers purchasing from multiple genres demonstrate broader purchasing preferences.
* Customer revenue contribution helps identify how revenue is distributed across the customer base.
* Cumulative and monthly revenue analysis provides a view of revenue performance over time.
