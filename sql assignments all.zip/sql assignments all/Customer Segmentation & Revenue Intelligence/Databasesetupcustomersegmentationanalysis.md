## Database Setup

The project uses the Chinook relational database in MySQL.

### Dataset Import Instructions

1. Open MySQL Workbench and connect to the MySQL server.
2. Open the `Chinook_MySql.sql` file located in the `database` folder.
3. Execute the complete SQL script in MySQL Workbench.
4. Verify that the `chinook` database has been created.
5. Run the following command:

```sql

USE chinook;

```

6. Verify the imported tables using:

```sql

SHOW TABLES;

```

The database should contain tables including:

* `artist`
* `album`
* `track`
* `genre`
* `customer`
* `employee`
* `invoice`
* `invoiceline`

After successfully importing the dataset, execute the queries in `customer_segmentation_analysis.sql` to perform the customer segmentation and revenue analysis.
