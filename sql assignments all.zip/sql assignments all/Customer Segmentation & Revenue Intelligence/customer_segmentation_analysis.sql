SHOW DATABASES;
USE chinook;

SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    c.Country,
    SUM(i.Total) AS TotalSpending
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId, CustomerName, c.Country
ORDER BY TotalSpending DESC;


SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    COUNT(i.InvoiceId) AS PurchaseCount
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId, CustomerName
ORDER BY PurchaseCount DESC;


SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    MAX(i.InvoiceDate) AS LastPurchaseDate
FROM Customer c
LEFT JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId, CustomerName
HAVING LastPurchaseDate IS NULL
    OR LastPurchaseDate < (
        SELECT DATE_SUB(MAX(InvoiceDate), INTERVAL 6 MONTH)
        FROM Invoice
    )
ORDER BY LastPurchaseDate;


SELECT
    c.Country,
    COUNT(DISTINCT c.CustomerId) AS CustomerCount,
    SUM(i.Total) AS TotalRevenue,
    AVG(customer_spending.TotalSpending) AS AverageCustomerSpending
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
JOIN (
    SELECT
        CustomerId,
        SUM(Total) AS TotalSpending
    FROM Invoice
    GROUP BY CustomerId
) customer_spending ON c.CustomerId = customer_spending.CustomerId
GROUP BY c.Country
ORDER BY AverageCustomerSpending DESC;


SELECT
    AVG(TotalSpending) AS AverageCustomerLifetimeSpending
FROM (
    SELECT
        CustomerId,
        SUM(Total) AS TotalSpending
    FROM Invoice
    GROUP BY CustomerId
) customer_totals;


WITH CustomerSpending AS (
    SELECT
        c.CustomerId,
        CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
        SUM(i.Total) AS TotalSpending
    FROM Customer c
    JOIN Invoice i ON c.CustomerId = i.CustomerId
    GROUP BY c.CustomerId, CustomerName
)
SELECT
    CustomerId,
    CustomerName,
    TotalSpending,
    CASE
        WHEN TotalSpending >= 40 THEN 'High Value'
        WHEN TotalSpending >= 20 THEN 'Medium Value'
        ELSE 'Low Value'
    END AS CustomerSegment
FROM CustomerSpending
ORDER BY TotalSpending DESC;


SELECT
    g.Name AS Genre,
    COUNT(il.InvoiceLineId) AS PurchaseCount
FROM InvoiceLine il
JOIN Track t ON il.TrackId = t.TrackId
JOIN Genre g ON t.GenreId = g.GenreId
GROUP BY g.GenreId, g.Name
ORDER BY PurchaseCount DESC;


SELECT
    ar.Name AS Artist,
    SUM(il.UnitPrice * il.Quantity) AS Revenue
FROM InvoiceLine il
JOIN Track t ON il.TrackId = t.TrackId
JOIN Album al ON t.AlbumId = al.AlbumId
JOIN Artist ar ON al.ArtistId = ar.ArtistId
GROUP BY ar.ArtistId, ar.Name
ORDER BY Revenue DESC;


SELECT
    t.TrackId,
    t.Name AS Track,
    COUNT(il.InvoiceLineId) AS PurchaseCount
FROM Track t
JOIN InvoiceLine il ON t.TrackId = il.TrackId
GROUP BY t.TrackId, t.Name
ORDER BY PurchaseCount DESC;


SELECT
    c.Country,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    SUM(i.Total) AS TotalSpending,
    RANK() OVER (
        PARTITION BY c.Country
        ORDER BY SUM(i.Total) DESC
    ) AS CountryRank
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId, CustomerName, c.Country
ORDER BY c.Country, CountryRank;


SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    SUM(i.Total) AS TotalSpending
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId, CustomerName
HAVING TotalSpending > (
    SELECT AVG(CustomerTotal)
    FROM (
        SELECT
            CustomerId,
            SUM(Total) AS CustomerTotal
        FROM Invoice
        GROUP BY CustomerId
    ) AS CustomerTotals
)
ORDER BY TotalSpending DESC;


WITH CustomerCountryRank AS (
    SELECT
        c.CustomerId,
        CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
        c.Country,
        SUM(i.Total) AS TotalSpending,
        ROW_NUMBER() OVER (
            PARTITION BY c.Country
            ORDER BY SUM(i.Total) DESC
        ) AS CountryRank
    FROM Customer c
    JOIN Invoice i ON c.CustomerId = i.CustomerId
    GROUP BY c.CustomerId, CustomerName, c.Country
)
SELECT
    CustomerId,
    CustomerName,
    Country,
    TotalSpending,
    CountryRank
FROM CustomerCountryRank
WHERE CountryRank <= 3
ORDER BY Country, CountryRank;


SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
    COUNT(DISTINCT g.GenreId) AS GenreCount
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
JOIN InvoiceLine il ON i.InvoiceId = il.InvoiceId
JOIN Track t ON il.TrackId = t.TrackId
JOIN Genre g ON t.GenreId = g.GenreId
GROUP BY c.CustomerId, CustomerName
HAVING GenreCount > 1
ORDER BY GenreCount DESC;


WITH CustomerRevenue AS (
    SELECT
        c.CustomerId,
        CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
        SUM(i.Total) AS TotalSpending
    FROM Customer c
    JOIN Invoice i ON c.CustomerId = i.CustomerId
    GROUP BY c.CustomerId, CustomerName
)
SELECT
    CustomerId,
    CustomerName,
    TotalSpending,
    ROUND(
        TotalSpending * 100.0 /
        (SELECT SUM(Total) FROM Invoice),
        2
    ) AS RevenueContributionPercentage
FROM CustomerRevenue
ORDER BY TotalSpending DESC;


WITH MonthlyRevenue AS (
    SELECT
        DATE_FORMAT(InvoiceDate, '%Y-%m') AS RevenueMonth,
        SUM(Total) AS MonthlyRevenue
    FROM Invoice
    GROUP BY DATE_FORMAT(InvoiceDate, '%Y-%m')
)
SELECT
    RevenueMonth,
    MonthlyRevenue,
    SUM(MonthlyRevenue) OVER (
        ORDER BY RevenueMonth
    ) AS CumulativeRevenue
FROM MonthlyRevenue
ORDER BY RevenueMonth;


SELECT
    DATE_FORMAT(InvoiceDate, '%Y-%m') AS RevenueMonth,
    SUM(Total) AS MonthlyRevenue
FROM Invoice
GROUP BY DATE_FORMAT(InvoiceDate, '%Y-%m')
ORDER BY MonthlyRevenue DESC
LIMIT 1;