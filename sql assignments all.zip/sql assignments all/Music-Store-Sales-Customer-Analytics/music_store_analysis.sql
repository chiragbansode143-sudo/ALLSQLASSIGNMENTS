USE chinook;

SELECT
    ROUND(SUM(UnitPrice * Quantity), 2) AS Total_Revenue
FROM invoiceline;

SELECT
    i.BillingCountry AS Country,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM invoice i
JOIN invoiceline il
    ON i.InvoiceId = il.InvoiceId
GROUP BY i.BillingCountry
ORDER BY Revenue DESC;

SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS Customer_Name,
    c.Country,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Total_Spending
FROM customer c
JOIN invoice i
    ON c.CustomerId = i.CustomerId
JOIN invoiceline il
    ON i.InvoiceId = il.InvoiceId
GROUP BY
    c.CustomerId,
    c.FirstName,
    c.LastName,
    c.Country
ORDER BY Total_Spending DESC
LIMIT 10;

SELECT
    ar.ArtistId,
    ar.Name AS Artist,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM artist ar
JOIN album al
    ON ar.ArtistId = al.ArtistId
JOIN track t
    ON al.AlbumId = t.AlbumId
JOIN invoiceline il
    ON t.TrackId = il.TrackId
GROUP BY
    ar.ArtistId,
    ar.Name
ORDER BY Revenue DESC;

SELECT
    g.GenreId,
    g.Name AS Genre,
    SUM(il.Quantity) AS Tracks_Purchased
FROM genre g
JOIN track t
    ON g.GenreId = t.GenreId
JOIN invoiceline il
    ON t.TrackId = il.TrackId
GROUP BY
    g.GenreId,
    g.Name
ORDER BY Tracks_Purchased DESC;

SELECT
    al.AlbumId,
    al.Title AS Album,
    ar.Name AS Artist,
    SUM(il.Quantity) AS Units_Sold,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM album al
JOIN artist ar
    ON al.ArtistId = ar.ArtistId
JOIN track t
    ON al.AlbumId = t.AlbumId
JOIN invoiceline il
    ON t.TrackId = il.TrackId
GROUP BY
    al.AlbumId,
    al.Title,
    ar.Name
ORDER BY Revenue DESC;

SELECT
    t.TrackId,
    t.Name AS Track,
    ar.Name AS Artist,
    SUM(il.Quantity) AS Purchase_Count
FROM track t
JOIN invoiceline il
    ON t.TrackId = il.TrackId
JOIN album al
    ON t.AlbumId = al.AlbumId
JOIN artist ar
    ON al.ArtistId = ar.ArtistId
GROUP BY
    t.TrackId,
    t.Name,
    ar.Name
ORDER BY Purchase_Count DESC
LIMIT 10;

WITH CustomerSpending AS (
    SELECT
        c.CustomerId,
        CONCAT(c.FirstName, ' ', c.LastName) AS Customer_Name,
        COALESCE(SUM(il.UnitPrice * il.Quantity), 0) AS Total_Spending
    FROM customer c
    LEFT JOIN invoice i
        ON c.CustomerId = i.CustomerId
    LEFT JOIN invoiceline il
        ON i.InvoiceId = il.InvoiceId
    GROUP BY
        c.CustomerId,
        c.FirstName,
        c.LastName
)
SELECT
    ROUND(AVG(Total_Spending), 2) AS Average_Customer_Spending
FROM CustomerSpending;

SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS Customer_Name,
    c.Country,
    c.Email
FROM customer c
LEFT JOIN invoice i
    ON c.CustomerId = i.CustomerId
WHERE i.InvoiceId IS NULL
ORDER BY Customer_Name;

SELECT
    e.EmployeeId,
    CONCAT(e.FirstName, ' ', e.LastName) AS Employee_Name,
    COUNT(DISTINCT c.CustomerId) AS Customers_Supported,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM employee e
JOIN customer c
    ON e.EmployeeId = c.SupportRepId
JOIN invoice i
    ON c.CustomerId = i.CustomerId
JOIN invoiceline il
    ON i.InvoiceId = il.InvoiceId
GROUP BY
    e.EmployeeId,
    e.FirstName,
    e.LastName
ORDER BY Revenue DESC;

WITH CountryRevenue AS (
    SELECT
        i.BillingCountry AS Country,
        SUM(il.UnitPrice * il.Quantity) AS Revenue
    FROM invoice i
    JOIN invoiceline il
        ON i.InvoiceId = il.InvoiceId
    GROUP BY i.BillingCountry
)
SELECT
    Country,
    ROUND(Revenue, 2) AS Revenue,
    ROUND(
        Revenue * 100.0 / SUM(Revenue) OVER (),
        2
    ) AS Revenue_Percentage
FROM CountryRevenue
ORDER BY Revenue DESC;

SELECT
    g.GenreId,
    g.Name AS Genre,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM genre g
JOIN track t
    ON g.GenreId = t.GenreId
JOIN invoiceline il
    ON t.TrackId = il.TrackId
GROUP BY
    g.GenreId,
    g.Name
ORDER BY Revenue DESC
LIMIT 1;

SELECT
    DATE_FORMAT(i.InvoiceDate, '%Y-%m') AS Month,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM invoice i
JOIN invoiceline il
    ON i.InvoiceId = il.InvoiceId
GROUP BY DATE_FORMAT(i.InvoiceDate, '%Y-%m')
ORDER BY Month;

SELECT
    YEAR(i.InvoiceDate) AS Year,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM invoice i
JOIN invoiceline il
    ON i.InvoiceId = il.InvoiceId
GROUP BY YEAR(i.InvoiceDate)
ORDER BY Year;

SELECT
    ar.ArtistId,
    ar.Name AS Artist,
    COUNT(t.TrackId) AS Track_Count
FROM artist ar
JOIN album al
    ON ar.ArtistId = al.ArtistId
JOIN track t
    ON al.AlbumId = t.AlbumId
GROUP BY
    ar.ArtistId,
    ar.Name
ORDER BY Track_Count DESC;

SELECT
    c.CustomerId,
    CONCAT(c.FirstName, ' ', c.LastName) AS Customer_Name,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Total_Spending
FROM customer c
JOIN invoice i
    ON c.CustomerId = i.CustomerId
JOIN invoiceline il
    ON i.InvoiceId = il.InvoiceId
GROUP BY
    c.CustomerId,
    c.FirstName,
    c.LastName
HAVING SUM(il.UnitPrice * il.Quantity) >
(
    SELECT AVG(Customer_Total)
    FROM
    (
        SELECT
            SUM(il2.UnitPrice * il2.Quantity) AS Customer_Total
        FROM invoice i2
        JOIN invoiceline il2
            ON i2.InvoiceId = il2.InvoiceId
        GROUP BY i2.CustomerId
    ) AS CustomerSpending
)
ORDER BY Total_Spending DESC;

WITH CustomerRevenue AS (
    SELECT
        c.CustomerId,
        CONCAT(c.FirstName, ' ', c.LastName) AS Customer_Name,
        SUM(il.UnitPrice * il.Quantity) AS Revenue
    FROM customer c
    JOIN invoice i
        ON c.CustomerId = i.CustomerId
    JOIN invoiceline il
        ON i.InvoiceId = il.InvoiceId
    GROUP BY
        c.CustomerId,
        c.FirstName,
        c.LastName
)
SELECT
    CustomerId,
    Customer_Name,
    ROUND(Revenue, 2) AS Revenue,
    RANK() OVER (ORDER BY Revenue DESC) AS Customer_Rank
FROM CustomerRevenue
ORDER BY Customer_Rank;

WITH CustomerRevenue AS (
    SELECT
        c.CustomerId,
        CONCAT(c.FirstName, ' ', c.LastName) AS Customer_Name,
        SUM(il.UnitPrice * il.Quantity) AS Revenue
    FROM customer c
    JOIN invoice i
        ON c.CustomerId = i.CustomerId
    JOIN invoiceline il
        ON i.InvoiceId = il.InvoiceId
    GROUP BY
        c.CustomerId,
        c.FirstName,
        c.LastName
)
SELECT
    CustomerId,
    Customer_Name,
    ROUND(Revenue, 2) AS Revenue,
    CASE
        WHEN Revenue >= 40 THEN 'High Value'
        WHEN Revenue >= 20 THEN 'Medium Value'
        ELSE 'Low Value'
    END AS Customer_Category
FROM CustomerRevenue
ORDER BY Revenue DESC;